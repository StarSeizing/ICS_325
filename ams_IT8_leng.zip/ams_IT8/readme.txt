Alumni Database

******* New Alumni Database Setup *******

1. Unzip the Alumni.zip file to htdocs folder (For example D:\xampp\htdocs). This will be refered to as the root for the remainder of the document.  
   
3. Create a mySQL database (let us call it as "alumni") and import the structure file alumni.sql located in the dataFiles folder of the root directory.  

5. Update the following parameters in the �db_configuration.php� file located in the root directory. 

   
 
   DEFINE('DATABASE_DATABASE', �alumni�);
  
   DEFINE('DATABASE_USER', �root�);
   
   DEFINE('DATABASE_PASSWORD', ��);
	
6. Once the database structure has been created, open a web browser and navigate to the instance of the site, i.e; localhost\root

   There was a default Admin user account created with the import. The credentials are:
   Username: admin@ams.com
   Password: 12345

   Login as the Admin
   On the list view of the alumni tab, click "Register Alumni" to add a new alumni user.
   Go to index.php and add images so that it can appear in a carasoul.
   Click the upload button to upload many images as you'd like. 

   Then on the alumni tab, press view to edit information about any alumni users and even upload images.
   Look on the navigation bar for Report Alumni to see a grid view of all of the alumni users.

	
7. Alumni users can be added by clicking the "Register Alumni" button in the list view of the main site and filling in the required data. 

8. Alumni data can be modified by clicking the "Modify" button in the row of the alumni that requires updating. 

9. Alumni users can be removed by clicking the "Delete" button in the row the alumni user is located at to be deleted. 

11. New users can be created by clicking "login" and then "sign up". By default the user is created as type "alumni" and not active (verified).
    There is a process to verify the new user through an email link that will need to be tested once the site is deployed to a blue host. 
    To bypass this while in development and testing the database administrator can go into the users table and update the active value to 1. At this time they can also change the type to "Admin" if the newly created user is an administrator. 

